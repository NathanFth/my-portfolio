import "../styles/Footer.css";
function Footer() {
  return <footer>&copy; Zyunth 2025</footer>;
}

export default Footer;
